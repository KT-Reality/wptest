=== KT PDF Manage ===
Author: Komalchand
Plugin URI: https://www.realitypremedia.com
Tags: PDF,manager
Requires at least: 1.1
 Tested up to: 4.7.3

== Description == 

We will provide separate documentation soon...

