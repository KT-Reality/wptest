<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class KTPDFManagerPDFs extends WP_List_Table {
   
	var $_categories_db_tbl_name = '';
	var $_pdfs_db_tbl_name = '';
	var $_pdfs_upload_path = '';
	var $_pdfs_upload_folder = '';

	var $_plugin_pages_name = array();
	
    function __construct( $args = array() ) {
        
        //Set parent defaults
        parent::__construct( array( 
            'singular' => 'kt-pdf-manager-pdfs',  //singular name of the listed records
            'plural'   => 'kt-pdf-manager-pdfs', //plural name of the listed records
            'ajax'     => false                          //does this table support ajax?
        ) );
       
	   $this->_categories_db_tbl_name = $args['categories_db_tbl_name'];
	   $this->_pdfs_db_tbl_name = $args['pdfs_db_tbl_name'];
	   $this->_pdfs_upload_path = $args['pdf_upload_path'];
	   $this->_pdfs_upload_folder = $args['pdf_upload_folder'];
	   $this->_plugin_pages_name = $args['pages_name_A'];
	   
	   $this->_pdfs_upload_path = $this->_pdfs_upload_path.$this->_pdfs_upload_folder;
    }

    function column_default( $item, $column_name ) {
        switch( $column_name ) {
			case 'id':
				echo $item['id_link'];
				break;
			case 'title':
				echo $item['title'];
				break;
            case 'file_name':
                echo $item['file_name'];
                break;
			case 'category':
				echo $item['category'];
				break;
			case 'last_date':
               	echo $item['last_date'];
                break;
        }
    }
   
    function column_cb( $item ) {
        return sprintf( 
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            esc_attr( $this->_args['singular'] ),
            esc_attr( $item['id'] )
        );
    }

    function get_columns() {
    	
		$columns = array(
							'cb'        		=> '<input type="checkbox"/>',
							'id'				=> 'ID',
							'title'     		=> 'Title',
							'file_name'     	=> 'File Name',
							'category'     		=> 'Category',
							'last_date' 		=> 'Date'
						);
        
        return $columns;
    }
	
	function extra_tablenav( $which ) {
		if ($which == 'bottom'){
			return;
		}
		
		global $wpdb;
		
		$sql = 'SELECT * FROM '.$this->_categories_db_tbl_name;
		$categoreies = $wpdb->get_results($sql);
		
		$select_str_header = '<div class="alignleft actions">
								<select name="kt_pdf_manager_categories" id="kt_pdf_manager_categories_id">';
		$select_str_footer = '	</select>
							  </div>';
		
		if (!$categoreies || count($categoreies) < 1){
			$select_str_body = '<option value="0">Please add category first</option>';
		}else{
			$current_category_id = 0;
			if( isset($_REQUEST['cat']) ){
				$current_category_id = $_REQUEST['cat'];
			}
			if( $current_category_id < 1 && isset($_REQUEST['kt_pdf_manager_pdf_edit_categories']) ){
				$current_category_id = $_REQUEST['kt_pdf_manager_pdf_edit_categories'];
			}
			$select_str_body = '<option value="0">Please select category</option>';
			foreach($categoreies as $category){
				if ($current_category_id == $category->id){
					$select_str_body .= '<option value="'.$category->id.'" selected>'.$category->cat_title.'</option>';
				}else{
					$select_str_body .= '<option value="'.$category->id.'">'.$category->cat_title.'</option>';
				}
			}
		}
		echo $select_str_header.$select_str_body.$select_str_footer;
	}
	
	function get_sortable_columns() {
		$c = array(
					'title' 	=> 'title',
					'category'  => 'cat_title',
					'last_date' => 'last_date'
					);
		
		return $c;
	}
   
    function get_bulk_actions() {
    
        $actions = array( 
            'delete'=> 'Delete'
        );
        
        return $actions;
    }

    function do_bulk_action() {
		global $wpdb;
		
		if( ( isset($_POST['action']) && $_POST['action'] == 'delete') || 
			( isset($_POST['action2']) && $_POST['action2'] == 'delete') ){
		$lists_id = isset( $_POST['kt-pdf-manager-pdfs'] ) ? $_POST['kt-pdf-manager-pdfs'] : false;
		if ( !$lists_id || !is_array( $lists_id ) || count( $lists_id ) < 1 ){
			return;
		}
		$ids = implode(',', $lists_id);
		$ids = trim($ids,',');
		
		//delete all files
		$sql = 'SELECT * FROM `'.$this->_pdfs_db_tbl_name.'` WHERE id IN('.$ids.')';
		$pdfs_records = $wpdb->get_results( $sql );
		if ($pdfs_records && count($pdfs_records) > 0){
			foreach($pdfs_records as $pdf_record ){
				if( $pdf_record->file_name && file_exists($this->_pdfs_upload_path.$pdf_record->file_name) ){
					unlink($this->_pdfs_upload_path.$pdf_record->file_name);
				}
			}
		}
		
		$sql = 'DELETE FROM `'.$this->_pdfs_db_tbl_name.'` WHERE id IN('.$ids.')';
		$wpdb->query( $sql );
    }
    }

    function get_data() {
		global $wpdb;
		
		$current_category_id = 0;
		$orderby = '';
		$order = '';
		if( isset($_REQUEST['cat']) ){
			$current_category_id = $_REQUEST['cat'];
		}
		if ( isset( $_REQUEST['orderby'] ) ){
			$orderby = $_REQUEST['orderby'];
		}
		if ( isset( $_REQUEST['order'] ) ){
			$order = $_REQUEST['order'];
		}
		$key_word = '';
		if ( isset( $_REQUEST['s'] ) ){
			$key_word = $_REQUEST['s'];
		}
		
		$sql = 'SELECT l.*, c.cat_title FROM '.$this->_pdfs_db_tbl_name.' AS l INNER JOIN '.$this->_categories_db_tbl_name.' AS c ON l.cat_id = c.id ';
		
		$whereCase = ' WHERE 1';
		if( $current_category_id ){
			$whereCase = ' WHERE l.cat_id = '.$current_category_id;
		}
		if( $key_word ){
			$search_whereCase = ' AND ( l.title LIKE %s OR l.file_name LIKE %s )';
			$whereCase .= $wpdb->prepare( $search_whereCase, '%'.$key_word.'%', '%'.$key_word.'%' );
		}
		
		$orderCase = ' ORDER BY l.last_date DESC';
		if( $orderby == 'cat_title' ){
			$orderCase = ' ORDER BY c.cat_title '.$order.', l.last_date DESC';
		}else if( $orderby == 'title' ){
			$orderCase = ' ORDER BY l.title '.$order.', l.last_date DESC';
		}else if( $orderby == 'last_date' ){
			$orderCase = ' ORDER BY l.last_date '.$order;
		}

		$all_pdfs = $wpdb->get_results($sql.$whereCase.$orderCase);
		if (!$all_pdfs || count($all_pdfs) < 1){
			return NULL;
		}
		
		
		$base = admin_url( 'admin.php?page=kt-pdf-manager-pdfs' );
		$edit_url = add_query_arg('view', 'edit', $base);
		$lists_data = array();
		foreach($all_pdfs as $pdf_record){
			$edit_url = add_query_arg('pdfid', $pdf_record->id, $edit_url);
			$file_str = '';
			if( $pdf_record->file_name && file_exists($this->_pdfs_upload_path.$pdf_record->file_name) ){
				$file_url = site_url().'/'.$this->_pdfs_upload_folder.$pdf_record->file_name;
				$file_str =  '<a href="'.$file_url.'" target="_blank">'.$pdf_record->file_name.'</a>';
			}
			$lists_data[] = array( 
								'id'				=> $pdf_record->id,
								'id_link' 			=> '<a href="'.$edit_url.'">'.$pdf_record->id.'</a>',
								'title'     		=> '<a href="'.$edit_url.'">'.$pdf_record->title.'</a>',
								'file_name'     	=> $file_str,
								'category'			=> $pdf_record->cat_title,
								'last_date' 		=> date('Y-m-d', strtotime($pdf_record->last_date)),
								 );
		}
		
		return $lists_data;
    }

    function prepare_items() {
       
        /**
         * First, lets decide how many records per page to show
         */
        $per_page = 20;
        $data = array();
		
        add_thickbox();

        $columns = $this->get_columns();
        $hidden = array(); // no hidden columns
       
        $this->_column_headers = array( $columns, $hidden );
       
        $this->do_bulk_action();
       
        $data = $this->get_data();
   
        $current_page = $this->get_pagenum();
    
        $total_items = count( $data );
       
	    if ($total_items > 0){
        	$data = array_slice( $data,( ( $current_page-1 )*$per_page ),$per_page );
		}
       
        $this->items = $data;

        $this->set_pagination_args( array( 
            'total_items' => $total_items,                  // We have to calculate the total number of items
            'per_page'    => $per_page,                     // We have to determine how many items to show on a page
            'total_pages' => ceil( $total_items/$per_page ) // We have to calculate the total number of pages
        ) );
        
    }
	
	function get_column_info() {

		 $columns = array( 
							'cb'        		=> '<input type="checkbox"/>',
							'id'				=> 'ID',
							'title'     		=> 'Title',
							'file_name'     	=> 'File Name',
							'category'     		=> 'Category',							
							'last_date' 		=> 'Date'
						);
		
		$hidden = array();

		$_sortable = apply_filters( "manage_{$this->screen->id}_sortable_columns", $this->get_sortable_columns() );

		$sortable = array();
		foreach ( $_sortable as $id => $data ) {
			if ( empty( $data ) )
				continue;

			$data = (array) $data;
			if ( !isset( $data[1] ) )
				$data[1] = false;

			$sortable[$id] = $data;
		}

		$_column_headers = array( $columns, $hidden, $sortable, array() );


		return $_column_headers;
	}   
}