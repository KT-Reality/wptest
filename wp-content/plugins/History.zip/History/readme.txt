=== Play Pause Button for Video ===

Contributors: Sunny Sehgal

Donate link: https://sunnysehgalblog.wordpress.com/

Tags: Play, Pause, video, button,  click, HTML5, video tag

Requires at least: 2.0.2

Tested up to: 4.7.3

Stable tag: 2

License: GPLv2 or later

== Description ==

This plugin used for add automatically 'Play Pause' button on video, which is implemented using 'HTML5 Video' tag.

= Features  =

*  Extremely easy to use

*  Responsive

*  Automatic add button to uploaded video

*  On hover button will be show

== Installation ==

1. Upload myplug folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Its automatically work on the uploaded vedio.

== Screenshots ==

1. The output.
