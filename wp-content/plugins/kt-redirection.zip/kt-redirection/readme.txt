=== Call to Action Metabox Module ===
Author: Komalchand
Web link: https://realitypremedia.com/
Tags: add, edit, delete, listing, search, assign, CTA
Requires at least: 1.0
Tested up to: 4.7.2
Stable tag: 2
License: GPLv2 or later

== Description ==

This plugin used for add edit delete and listing module at admin side. Also user can search and sort cta records.
There is also short code implementation for client side.


A few notes about the sections above:

*   Komalchand
*   add, edit, delete, listing, searching
*   "1.0" is the lowest version that the plugin will work on
*   "4.7.2" is the highest version that you've *successfully used to test the plugin*. Note that it might work on
higher versions... this is just the highest one you've verified.

== Installation ==

1. Upload kt-cta-bottom-meta folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. For display listing page at front side use short code [vmember_List].
